//práctica 3: Modelado Geométrico y Cámara Sintética.

#include <stdio.h>
#include <string.h>
#include <cmath>
#include <vector>

#include <glew.h>
#include <glfw3.h>

//glm
#include <glm.hpp>
#include <gtc\matrix_transform.hpp>
#include <gtc\type_ptr.hpp>

#include "Mesh.h"
#include "Shader.h"
#include "Window.h"
#include "Camera.h"


using std::vector;


//Dimensiones de la ventana
const float toRadians = 3.14159265f / 180.0f;

GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;

static double limitFPS = 1.0 / 60.0;


Camera camera;
Window mainWindow;

vector<Mesh*> meshList;
vector<Shader> shaderList;


//Vertex Shader
static const char* vShader = "shaders/shader.vert";
static const char* fShader = "shaders/shader.frag";



//===============================================================
//CUBO PEQUEÑO PARA LOS ROMBOS DEL HOLOCRON
//===============================================================

void CrearCuboHolocron()
{
	unsigned int cubo_indices[] = {

		//frontal
		0,1,2,
		2,3,0,

		//derecha
		1,5,6,
		6,2,1,

		//trasera
		7,6,5,
		5,4,7,

		//izquierda
		4,0,3,
		3,7,4,

		//inferior
		4,5,1,
		1,0,4,

		//superior
		3,2,6,
		6,7,3
	};


	GLfloat cubo_vertices[] = {

		//frontal
		-0.353553f,-0.353553f, 0.353553f,
		 0.353553f,-0.353553f, 0.353553f,
		 0.353553f, 0.353553f, 0.353553f,
		-0.353553f, 0.353553f, 0.353553f,

		//trasera
		-0.353553f,-0.353553f,-0.353553f,
		 0.353553f,-0.353553f,-0.353553f,
		 0.353553f, 0.353553f,-0.353553f,
		-0.353553f, 0.353553f,-0.353553f
	};


	Mesh* cuboHolocron = new Mesh();

	cuboHolocron->CreateMesh(
		cubo_vertices,
		cubo_indices,
		24,
		36
	);

	meshList.push_back(cuboHolocron);
}



//===============================================================
//PIRAMIDE TRIANGULAR DE UNA ESQUINA
//===============================================================

void CrearPiramideEsquina(float sx, float sy, float sz)
{
	unsigned int indices[] = {

		0,1,2,
		0,2,3,
		0,3,1,
		1,3,2

	};


	GLfloat vertices[] = {

		//Punta exterior de la esquina
		0.5f * sx, 0.5f * sy, 0.5f * sz,

		//Puntos medios de las tres caras
		0.0f,      0.5f * sy, 0.5f * sz,
		0.5f * sx, 0.0f,      0.5f * sz,
		0.5f * sx, 0.5f * sy, 0.0f

	};


	Mesh* piramideEsquina = new Mesh();

	piramideEsquina->CreateMesh(
		vertices,
		indices,
		12,
		12
	);

	meshList.push_back(piramideEsquina);
}



//===============================================================
//PLANO DEL PISO
//===============================================================

void CrearPiso()
{
	unsigned int indices[] = {

		0,1,2,
		0,2,3

	};


	GLfloat vertices[] = {

		-4.0f, 0.0f,  4.0f,
		 4.0f, 0.0f,  4.0f,
		 4.0f, 0.0f, -4.0f,
		-4.0f, 0.0f, -4.0f

	};


	Mesh* piso = new Mesh();

	piso->CreateMesh(
		vertices,
		indices,
		12,
		6
	);

	meshList.push_back(piso);
}



//===============================================================
//SHADER
//===============================================================

void CreateShaders()
{
	Shader* shader1 = new Shader();

	shader1->CreateFromFiles(vShader, fShader);

	shaderList.push_back(*shader1);
}



//===============================================================
//MAIN
//===============================================================

int main()
{

	mainWindow = Window(800, 600);
	mainWindow.Initialise();


	//===============================================================
	//CREAR OBJETOS
	//===============================================================


	CrearCuboHolocron();						//meshList[0]


	//PIRAMIDES FRONTALES

	CrearPiramideEsquina(-1.0f, 1.0f, 1.0f);	//meshList[1] Amarilla

	CrearPiramideEsquina(1.0f, 1.0f, 1.0f);		//meshList[2] Roja

	CrearPiramideEsquina(-1.0f,-1.0f, 1.0f);	//meshList[3] Magenta

	CrearPiramideEsquina(1.0f,-1.0f, 1.0f);		//meshList[4] Verde


	//PIRAMIDES TRASERAS

	CrearPiramideEsquina(-1.0f, 1.0f,-1.0f);	//meshList[5] Verde

	CrearPiramideEsquina(1.0f, 1.0f,-1.0f);		//meshList[6] Magenta

	CrearPiramideEsquina(-1.0f,-1.0f,-1.0f);	//meshList[7] Roja

	CrearPiramideEsquina(1.0f,-1.0f,-1.0f);		//meshList[8] Amarilla


	CrearPiso();								//meshList[9]


	CreateShaders();



	//===============================================================
	//CAMARA
	//===============================================================


	camera = Camera(
		glm::vec3(0.0f, 1.3f, 1.5f),
		glm::vec3(0.0f, 1.0f, 0.0f),
		-90.0f,
		-9.0f,
		0.3f,
		0.3f
	);



	//===============================================================
	//UNIFORMS
	//===============================================================


	GLuint uniformProjection = 0;

	GLuint uniformModel = 0;

	GLuint uniformView = 0;

	GLuint uniformColor = 0;



	glm::mat4 projection = glm::perspective(
		glm::radians(60.0f),
		mainWindow.getBufferWidth() / mainWindow.getBufferHeight(),
		0.1f,
		100.0f
	);


	glm::vec3 color = glm::vec3(
		0.0f,
		0.0f,
		0.0f
	);



	//===============================================================
	//HOLOCRON JEDI
	//===============================================================



	//===============================================================
	//6 CUBOS
	//===============================================================


	//Cubo frontal
	glm::mat4 modelHCCuboFrontal(1.0f);
	modelHCCuboFrontal = glm::translate(modelHCCuboFrontal, glm::vec3(0.0f, 0.0f, -6.853553f));
	modelHCCuboFrontal = glm::rotate(modelHCCuboFrontal, 45.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));


	//Cubo trasero
	glm::mat4 modelHCCuboTrasero(1.0f);
	modelHCCuboTrasero = glm::translate(modelHCCuboTrasero, glm::vec3(0.0f, 0.0f, -7.146447f));
	modelHCCuboTrasero = glm::rotate(modelHCCuboTrasero, 45.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));


	//Cubo derecho
	glm::mat4 modelHCCuboDerecho(1.0f);
	modelHCCuboDerecho = glm::translate(modelHCCuboDerecho, glm::vec3(0.146447f, 0.0f, -7.0f));
	modelHCCuboDerecho = glm::rotate(modelHCCuboDerecho, 45.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));


	//Cubo izquierdo
	glm::mat4 modelHCCuboIzquierdo(1.0f);
	modelHCCuboIzquierdo = glm::translate(modelHCCuboIzquierdo, glm::vec3(-0.146447f, 0.0f, -7.0f));
	modelHCCuboIzquierdo = glm::rotate(modelHCCuboIzquierdo, 45.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));


	//Cubo superior
	glm::mat4 modelHCCuboSuperior(1.0f);
	modelHCCuboSuperior = glm::translate(modelHCCuboSuperior, glm::vec3(0.0f, 0.146447f, -7.0f));
	modelHCCuboSuperior = glm::rotate(modelHCCuboSuperior, 45.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));


	//Cubo inferior
	glm::mat4 modelHCCuboInferior(1.0f);
	modelHCCuboInferior = glm::translate(modelHCCuboInferior, glm::vec3(0.0f, -0.146447f, -7.0f));
	modelHCCuboInferior = glm::rotate(modelHCCuboInferior, 45.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));



	//===============================================================
	//8 PIRAMIDES
	//===============================================================


	//Todas las piramides ya tienen su esquina en sus vertices.
	//Solo las trasladamos al centro del Holocron.


	//Piramide superior izquierda frontal
	glm::mat4 modelHCPiramideSIF(1.0f);
	modelHCPiramideSIF = glm::translate(modelHCPiramideSIF, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide superior derecha frontal
	glm::mat4 modelHCPiramideSDF(1.0f);
	modelHCPiramideSDF = glm::translate(modelHCPiramideSDF, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide inferior izquierda frontal
	glm::mat4 modelHCPiramideIIF(1.0f);
	modelHCPiramideIIF = glm::translate(modelHCPiramideIIF, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide inferior derecha frontal
	glm::mat4 modelHCPiramideIDF(1.0f);
	modelHCPiramideIDF = glm::translate(modelHCPiramideIDF, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide superior izquierda trasera
	glm::mat4 modelHCPiramideSIT(1.0f);
	modelHCPiramideSIT = glm::translate(modelHCPiramideSIT, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide superior derecha trasera
	glm::mat4 modelHCPiramideSDT(1.0f);
	modelHCPiramideSDT = glm::translate(modelHCPiramideSDT, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide inferior izquierda trasera
	glm::mat4 modelHCPiramideIIT(1.0f);
	modelHCPiramideIIT = glm::translate(modelHCPiramideIIT, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide inferior derecha trasera
	glm::mat4 modelHCPiramideIDT(1.0f);
	modelHCPiramideIDT = glm::translate(modelHCPiramideIDT, glm::vec3(0.0f, 0.0f, -7.0f));



	//===============================================================
	//PISO
	//===============================================================


	glm::mat4 modelPiso(1.0f);
	modelPiso = glm::translate(modelPiso, glm::vec3(0.0f, -0.52f, -7.0f));



	//===============================================================
	//WHILE
	//===============================================================


	while (!mainWindow.getShouldClose())
	{

		GLfloat now = glfwGetTime();

		deltaTime = now - lastTime;

		deltaTime += (now - lastTime) / limitFPS;

		lastTime = now;


		//Recibir eventos del usuario
		glfwPollEvents();


		//Cámara
		camera.keyControl(mainWindow.getsKeys(), deltaTime);

		camera.mouseControl(
			mainWindow.getXChange(),
			mainWindow.getYChange()
		);



		//===============================================================
		//LIMPIAR VENTANA
		//===============================================================


		//Gris para poder observar el piso negro
		glClearColor(
			0.25f,
			0.25f,
			0.25f,
			1.0f
		);


		glClear(
			GL_COLOR_BUFFER_BIT |
			GL_DEPTH_BUFFER_BIT
		);



		//===============================================================
		//PISO NEGRO
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiso));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 0.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();



		//===============================================================
		//CUBO FRONTAL - AZUL
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboFrontal));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();



		//===============================================================
		//CUBO TRASERO - AZUL
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboTrasero));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();



		//===============================================================
		//CUBO DERECHO - CAFE
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboDerecho));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.478f, 0.255f, 0.067f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();



		//===============================================================
		//CUBO IZQUIERDO - CAFE
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboIzquierdo));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.478f, 0.255f, 0.067f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();



		//===============================================================
		//CUBO SUPERIOR - CYAN
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboSuperior));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 1.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();



		//===============================================================
		//CUBO INFERIOR - CYAN
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboInferior));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 1.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE SUPERIOR IZQUIERDA FRONTAL - AMARILLA
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSIF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[1]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE SUPERIOR DERECHA FRONTAL - ROJA
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSDF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[2]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE INFERIOR IZQUIERDA FRONTAL - MAGENTA
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIIF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[3]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE INFERIOR DERECHA FRONTAL - VERDE
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIDF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE SUPERIOR IZQUIERDA TRASERA - VERDE
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSIT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE SUPERIOR DERECHA TRASERA - MAGENTA
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSDT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[6]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE INFERIOR IZQUIERDA TRASERA - ROJA
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIIT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();



		//===============================================================
		//PIRAMIDE INFERIOR DERECHA TRASERA - AMARILLA
		//===============================================================


		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIDT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);

		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();



		//===============================================================


		glUseProgram(0);

		mainWindow.swapBuffers();

	}


	return 0;
}