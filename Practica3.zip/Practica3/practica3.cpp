//pr�ctica 3: Modelado Geom�trico y C�mara Sint�tica.
#include <stdio.h>
#include <string.h>
#include<cmath>
#include<vector>
#include <glew.h>
#include <glfw3.h>
//glm
#include<glm.hpp>
#include<gtc\matrix_transform.hpp>
#include<gtc\type_ptr.hpp>
#include <gtc\random.hpp>
//clases para dar orden y limpieza al c�digo
#include"Mesh.h"
#include"Shader.h"
#include"Sphere.h"
#include"Window.h"
#include"Camera.h"
//tecla E: Rotar sobre el eje X
//tecla R: Rotar sobre el eje Y
//tecla T: Rotar sobre el eje Z


using std::vector;

//Dimensiones de la ventana
const float toRadians = 3.14159265f/180.0; //grados a radianes
const float PI = 3.14159265f;
GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;
static double limitFPS = 1.0 / 60.0;
Camera camera;
Window mainWindow;
vector<Mesh*> meshList;
vector<Shader>shaderList;
//Vertex Shader
static const char* vShader = "shaders/shader.vert";
static const char* fShader = "shaders/shader.frag";
static const char* vShaderColor = "shaders/shadercolor.vert";
Sphere sp = Sphere(1.0, 20, 20); //recibe radio, slices, stacks




void CrearCubo()
{
	unsigned int cubo_indices[] = {
		// front
		0, 1, 2,
		2, 3, 0,
		// right
		1, 5, 6,
		6, 2, 1,
		// back
		7, 6, 5,
		5, 4, 7,
		// left
		4, 0, 3,
		3, 7, 4,
		// bottom
		4, 5, 1,
		1, 0, 4,
		// top
		3, 2, 6,
		6, 7, 3
	};

	GLfloat cubo_vertices[] = {
		// front
		-0.5f, -0.5f,  0.5f,
		0.5f, -0.5f,  0.5f,
		0.5f,  0.5f,  0.5f,
		-0.5f,  0.5f,  0.5f,
		// back
		-0.5f, -0.5f, -0.5f,
		0.5f, -0.5f, -0.5f,
		0.5f,  0.5f, -0.5f,
		-0.5f,  0.5f, -0.5f
	};
	Mesh* cubo = new Mesh();
	cubo->CreateMesh(cubo_vertices, cubo_indices, 24, 36);
	meshList.push_back(cubo);
}

// Pir�mide triangular regular
void CrearPiramideTriangular()
{
	unsigned int indices_piramide_triangular[] = {
			0,1,2,
			1,3,2,
			3,0,2,
			1,0,3

	};
	GLfloat vertices_piramide_triangular[] = {
		-0.5f, -0.5f,0.0f,	//0
		0.5f,-0.5f,0.0f,	//1
		0.0f,0.5f, -0.25f,	//2
		0.0f,-0.5f,-0.5f,	//3

	};
	Mesh* piramidet = new Mesh();
	piramidet->CreateMesh(vertices_piramide_triangular, indices_piramide_triangular, 12, 12);
	meshList.push_back(piramidet);

}


//funci�n para crear pir�mide cuadrangular unitaria
void CrearPiramideCuadrangular()
{
	unsigned int piramidecuadrangular_indices[] = {
		0,3,4,//frontal
		3,2,4,//izquierda
		2,1,4,//trasera
		1,0,4,//derecha
		0,1,2,//abajo1
		0,2,3//abajo2

	};
	GLfloat piramidecuadrangular_vertices[] = {
		0.5f,-0.5f,0.5f,
		0.5f,-0.5f,-0.5f,
		-0.5f,-0.5f,-0.5f,
		-0.5f,-0.5f,0.5f,
		0.0f,0.5f,0.0f,
	};
	Mesh* piramidec = new Mesh();
	piramidec->CreateMesh(piramidecuadrangular_vertices, piramidecuadrangular_indices, 15, 18);
	meshList.push_back(piramidec);
}

//PLANO DEL PISO
void CrearPiso()
{
	unsigned int indices[] = {
		0,1,2,
		0,2,3
	};

	GLfloat vertices[] = {
		-4.0f, 0.0f,  4.0f,
		 4.0f, 0.0f,  4.0f,
		 4.0f, 0.0f, -4.0f,
		-4.0f, 0.0f, -4.0f
	};

	Mesh* piso = new Mesh();
	piso->CreateMesh(vertices, indices, 12, 6);
	meshList.push_back(piso);
}

//PIRAMIDE TRIANGULAR PARA LAS ESQUINAS DEL HOLOCRON
void CrearPiramideHolocron()
{
	unsigned int indices[] = {
		0,1,2,
		0,2,3,
		0,3,1,
		1,3,2
	};

	GLfloat vertices[] = {
		0.70f,0.70f,0.70f,	//0 punta de la esquina
		0.0f,0.70f,0.70f,	//1
		0.70f,0.0f,0.70f,	//2
		0.70f,0.70f,0.0f	//3
	};

	Mesh* piramideHolocron = new Mesh();
	piramideHolocron->CreateMesh(vertices, indices, 12, 12);
	meshList.push_back(piramideHolocron);
}

//PIRAMIDE CUADRANGULAR CON UNA MESH POR CADA CARA
void CrearPiramideCuadrangularColores()
{
	//CARA FRONTAL
	unsigned int indicesFrontal[] = {
		0,1,2
	};

	GLfloat verticesFrontal[] = {
		 0.5f,-0.5f, 0.5f,
		-0.5f,-0.5f, 0.5f,
		 0.0f, 0.5f, 0.0f
	};

	Mesh* caraFrontal = new Mesh();
	caraFrontal->CreateMesh(verticesFrontal, indicesFrontal, 9, 3);
	meshList.push_back(caraFrontal);


	//CARA IZQUIERDA
	unsigned int indicesIzquierda[] = {
		0,1,2
	};

	GLfloat verticesIzquierda[] = {
		-0.5f,-0.5f, 0.5f,
		-0.5f,-0.5f,-0.5f,
		 0.0f, 0.5f, 0.0f
	};

	Mesh* caraIzquierda = new Mesh();
	caraIzquierda->CreateMesh(verticesIzquierda, indicesIzquierda, 9, 3);
	meshList.push_back(caraIzquierda);


	//CARA TRASERA
	unsigned int indicesTrasera[] = {
		0,1,2
	};

	GLfloat verticesTrasera[] = {
		-0.5f,-0.5f,-0.5f,
		 0.5f,-0.5f,-0.5f,
		 0.0f, 0.5f, 0.0f
	};

	Mesh* caraTrasera = new Mesh();
	caraTrasera->CreateMesh(verticesTrasera, indicesTrasera, 9, 3);
	meshList.push_back(caraTrasera);


	//CARA DERECHA
	unsigned int indicesDerecha[] = {
		0,1,2
	};

	GLfloat verticesDerecha[] = {
		 0.5f,-0.5f,-0.5f,
		 0.5f,-0.5f, 0.5f,
		 0.0f, 0.5f, 0.0f
	};

	Mesh* caraDerecha = new Mesh();
	caraDerecha->CreateMesh(verticesDerecha, indicesDerecha, 9, 3);
	meshList.push_back(caraDerecha);


	//BASE CUADRADA
	unsigned int indicesBase[] = {
		0,1,2,
		0,2,3
	};

	GLfloat verticesBase[] = {
		 0.5f,-0.5f, 0.5f,
		 0.5f,-0.5f,-0.5f,
		-0.5f,-0.5f,-0.5f,
		-0.5f,-0.5f, 0.5f
	};

	Mesh* base = new Mesh();
	base->CreateMesh(verticesBase, indicesBase, 12, 6);
	meshList.push_back(base);
}


/*
Crear cilindro, cono y esferas con arreglos din�micos vector creados en el Semestre 2023 - 1 : por S�nchez P�rez Omar Alejandro
*/
void CrearCilindro(int res, float R) {

	//constantes utilizadas en los ciclos for
	int n, i;
	//c�lculo del paso interno en la circunferencia y variables que almacenar�n cada coordenada de cada v�rtice
	GLfloat dt = 2 * PI / res, x, z, y = -0.5f;

	vector<GLfloat> vertices;
	vector<unsigned int> indices;

	//ciclo for para crear los v�rtices de las paredes del cilindro
	for (n = 0; n <= (res); n++) {
		if (n != res) {
			x = R * cos((n)*dt);
			z = R * sin((n)*dt);
		}
		//caso para terminar el c�rculo
		else {
			x = R * cos((0)*dt);
			z = R * sin((0)*dt);
		}
		for (i = 0; i < 6; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(y);
				break;
			case 2:
				vertices.push_back(z);
				break;
			case 3:
				vertices.push_back(x);
				break;
			case 4:
				vertices.push_back(0.5);
				break;
			case 5:
				vertices.push_back(z);
				break;
			}
		}
	}

	//ciclo for para crear la circunferencia inferior
	for (n = 0; n <= (res); n++) {
		x = R * cos((n)*dt);
		z = R * sin((n)*dt);
		for (i = 0; i < 3; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(-0.5f);
				break;
			case 2:
				vertices.push_back(z);
				break;
			}
		}
	}

	//ciclo for para crear la circunferencia superior
	for (n = 0; n <= (res); n++) {
		x = R * cos((n)*dt);
		z = R * sin((n)*dt);
		for (i = 0; i < 3; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(0.5);
				break;
			case 2:
				vertices.push_back(z);
				break;
			}
		}
	}

	//Se generan los indices de los v�rtices
	for (i = 0; i < vertices.size(); i++) indices.push_back(i);

	//se genera el mesh del cilindro
	Mesh *cilindro = new Mesh();
	cilindro->CreateMeshGeometry(vertices, indices, vertices.size(), indices.size());
	meshList.push_back(cilindro);
}

//funci�n para crear un cono
void CrearCono(int res,float R) {

	//constantes utilizadas en los ciclos for
	int n, i;
	//c�lculo del paso interno en la circunferencia y variables que almacenar�n cada coordenada de cada v�rtice
	GLfloat dt = 2 * PI / res, x, z, y = -0.5f;
	
	vector<GLfloat> vertices;
	vector<unsigned int> indices;

	//caso inicial para crear el cono
	vertices.push_back(0.0);
	vertices.push_back(0.5);
	vertices.push_back(0.0);
	
	//ciclo for para crear los v�rtices de la circunferencia del cono
	for (n = 0; n <= (res); n++) {
		x = R * cos((n)*dt);
		z = R * sin((n)*dt);
		for (i = 0; i < 3; i++) {
			switch (i) {
			case 0:
				vertices.push_back(x);
				break;
			case 1:
				vertices.push_back(y);
				break;
			case 2:
				vertices.push_back(z);
				break;
			}
		}
	}
	vertices.push_back(R * cos(0) * dt);
	vertices.push_back(-0.5);
	vertices.push_back(R * sin(0) * dt);


	for (i = 0; i < res+2; i++) indices.push_back(i);

	//se genera el mesh del cono
	Mesh *cono = new Mesh();
	cono->CreateMeshGeometry(vertices, indices, vertices.size(), res + 2);
	meshList.push_back(cono);
}


void CreateShaders()
{
	Shader *shader1 = new Shader();
	shader1->CreateFromFiles(vShader, fShader);
	shaderList.push_back(*shader1);

	Shader* shader2 = new Shader();
	shader2->CreateFromFiles(vShaderColor, fShader);
	shaderList.push_back(*shader2);
}


int main()
{
	mainWindow = Window(800, 600);
	mainWindow.Initialise();
	//Cilindro y cono reciben resoluci�n (slices, rebanadas) y Radio de circunferencia de la base y tapa

	CrearCubo();//�ndice 0 en MeshList
	CrearPiramideTriangular();//�ndice 1 en MeshList
	CrearCilindro(25, 1.0f);//�ndice 2 en MeshList
	CrearCono(25, 1.0f);//�ndice 3 en MeshList
	CrearPiramideCuadrangular();//�ndice 4 en MeshList
	CrearPiramideHolocron();//�ndice 5 en MeshList
	CrearPiso();//�ndice 6 en MeshList
	CrearPiramideCuadrangularColores();//indice 7-11 en MeshList
	CreateShaders();



	/*C�mara se usa el comando: glm::lookAt(vector de posici�n, vector de orientaci�n, vector up));
	En la clase Camera se reciben 5 datos:
	glm::vec3 vector de posici�n,
	glm::vec3 vector up,
	GlFloat yaw rotaci�n para girar hacia la derecha e izquierda
	GlFloat pitch rotaci�n para inclinar hacia arriba y abajo
	GlFloat velocidad de desplazamiento,
	GlFloat velocidad de vuelta o de giro
	Se usa el Mouse y las teclas WASD y su posici�n inicial est� en 0,0,1 y ve hacia 0,0,-1.
	*/

	camera = Camera(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f), -60.0f, 0.0f, 0.3f, 0.3f);


	GLuint uniformProjection = 0;
	GLuint uniformModel = 0;
	GLuint uniformView = 0;
	GLuint uniformColor = 0;
	glm::mat4 projection = glm::perspective(glm::radians(60.0f), mainWindow.getBufferWidth() / mainWindow.getBufferHeight(), 0.1f, 100.0f);
	//glm::mat4 projection = glm::ortho(-1, 1, -1, 1, 1, 10);

	//Loop mientras no se cierra la ventana
	sp.init(); //inicializar esfera
	sp.load();//enviar la esfera al shader

	glm::mat4 model(1.0);//Inicializar matriz de Modelo 4x4

	glm::vec3 color = glm::vec3(0.0f, 0.0f, 0.0f); //inicializar Color para enviar a variable Uniform;

	// COMIENZO A CREAR LA FIGURA 2 

	glm::mat4 modelCuboAmarillo(1.0f);
	modelCuboAmarillo = glm::translate(modelCuboAmarillo, glm::vec3(-4.1f, 1.3f, -7.0f));
	// para que quede como la esquina de un cuadrado lo rotamos  grados sobre el eje z
	//modelCuboAmarillo = glm::rotate(modelCuboAmarillo, 45.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));

	glm::mat4 modelCuboRojo(1.0f);
	modelCuboRojo = glm::translate(modelCuboRojo, glm::vec3(-3.1f, 1.3f, -7.0f));
	// para que quede como la esquina de un cuadrado lo rotamos 4 grados sobre el eje z
	//modelCuboRojo = glm::rotate(modelCuboRojo, -45.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));

	glm::mat4 modelCuboMagenta(1.0f);
	modelCuboMagenta = glm::translate(modelCuboMagenta, glm::vec3(-4.1f, 0.5f, -7.0f));
	// para que quede como la esquina de un cuadrado lo rotamos 4 grados sobre el eje z
	//modelCuboMagenta = glm::rotate(modelCuboMagenta, 135.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));

	//cubo azul//PIRAMIDE VERDE
	glm::mat4 modelCuboVerde(1.0f);
	modelCuboVerde = glm::translate(modelCuboVerde, glm::vec3(-3.1f, 0.5f, -7.0f));
	// para que quede como la esquina de un cuadrado lo rotamos ciento treinta y cinco grados sobre el eje z
	//modelTrianguloVerde = glm::rotate(modelTrianguloVerde, -135.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));glm::mat4 modelCuboAzul(1.0f);

	//cubo azul
	glm::mat4 modelCuboAzul(1.0f);
	modelCuboAzul = glm::translate(modelCuboAzul, glm::vec3(-3.6f, 0.9f, -6.5f));
	// para que quede como la esquina de un cuadrado lo rotamos 45 grados sobre el eje z
	modelCuboAzul = glm::rotate(modelCuboAzul, 45.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));

	//PIRAMIDE CAFE
	glm::mat4 modelPiramideCafe(1.0f);
	modelPiramideCafe = glm::translate(modelPiramideCafe, glm::vec3(-3.5f, 0.9f, -6.0f));
	// para que el cuadrado se vea como rombo
	modelPiramideCafe = glm::rotate(modelPiramideCafe, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

	//La trifuerza que no es trifuerza pero tiene la forma de la trifuerza

	//Tri�mngulo amarillo
	glm::mat4 modelTrianguloAmarillo(1.0f);
	modelTrianguloAmarillo = glm::translate(modelTrianguloAmarillo, glm::vec3(0.0f, 0.5f, -7.0f));
	modelTrianguloAmarillo = glm::rotate(modelTrianguloAmarillo, 180.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
	//tri�ngulo Verde
	glm::mat4 modelTrianguloVerde(1.0f);
	modelTrianguloVerde = glm::translate(modelTrianguloVerde, glm::vec3(-0.5f, 0.5f, -6.5f));
	//tri�ngulo Rojo
	glm::mat4 modelTrianguloRojo(1.0f);
	modelTrianguloRojo = glm::translate(modelTrianguloRojo, glm::vec3(0.5f, 0.5f, -6.5f));
	//Tri�ngulo Azul
	glm::mat4 modelTrianguloMagenta(1.0f);
	modelTrianguloMagenta = glm::translate(modelTrianguloMagenta, glm::vec3(0.0f, 1.5f, -7.0f));

	//HOLOCR�N JEDI

		//HOLOCR�N JEDI

	//3 CUBOS CENTRALES

	//3 CUBOS CENTRALES

	//Cubo frontal y trasero
	glm::mat4 modelHCCuboFrontalTrasero(1.0f);
	modelHCCuboFrontalTrasero = glm::translate(modelHCCuboFrontalTrasero, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCCuboFrontalTrasero = glm::rotate(modelHCCuboFrontalTrasero, 45.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
	modelHCCuboFrontalTrasero = glm::scale(modelHCCuboFrontalTrasero, glm::vec3(0.99f, 0.99f, 1.4f));

	//Cubo izquierdo y derecho
	glm::mat4 modelHCCuboIzquierdoDerecho(1.0f);
	modelHCCuboIzquierdoDerecho = glm::translate(modelHCCuboIzquierdoDerecho, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCCuboIzquierdoDerecho = glm::rotate(modelHCCuboIzquierdoDerecho, 45.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
	modelHCCuboIzquierdoDerecho = glm::scale(modelHCCuboIzquierdoDerecho, glm::vec3(1.4f, 0.99f, 0.99f));

	//Cubo superior e inferior
	glm::mat4 modelHCCuboSuperiorInferior(1.0f);
	modelHCCuboSuperiorInferior = glm::translate(modelHCCuboSuperiorInferior, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCCuboSuperiorInferior = glm::rotate(modelHCCuboSuperiorInferior, 45.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
	modelHCCuboSuperiorInferior = glm::scale(modelHCCuboSuperiorInferior, glm::vec3(0.99f, 1.4f, 0.99f));
	//8 PIRAMIDES DE LAS ESQUINAS


	//Piramide superior derecha frontal
	glm::mat4 modelHCPiramideSDF(1.0f);
	modelHCPiramideSDF = glm::translate(modelHCPiramideSDF, glm::vec3(0.0f, 0.0f, -7.0f));


	//Piramide superior izquierda frontal
	glm::mat4 modelHCPiramideSIF(1.0f);
	modelHCPiramideSIF = glm::translate(modelHCPiramideSIF, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCPiramideSIF = glm::rotate(modelHCPiramideSIF, -90.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));


	//Piramide inferior izquierda frontal
	glm::mat4 modelHCPiramideIIF(1.0f);
	modelHCPiramideIIF = glm::translate(modelHCPiramideIIF, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCPiramideIIF = glm::rotate(modelHCPiramideIIF, 180.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));


	//Piramide inferior derecha frontal
	glm::mat4 modelHCPiramideIDF(1.0f);
	modelHCPiramideIDF = glm::translate(modelHCPiramideIDF, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCPiramideIDF = glm::rotate(modelHCPiramideIDF, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));


	//Piramide superior izquierda trasera
	glm::mat4 modelHCPiramideSIT(1.0f);
	modelHCPiramideSIT = glm::translate(modelHCPiramideSIT, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCPiramideSIT = glm::rotate(modelHCPiramideSIT, 180.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));


	//Piramide superior derecha trasera
	glm::mat4 modelHCPiramideSDT(1.0f);
	modelHCPiramideSDT = glm::translate(modelHCPiramideSDT, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCPiramideSDT = glm::rotate(modelHCPiramideSDT, -90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));


	//Piramide inferior izquierda trasera
	glm::mat4 modelHCPiramideIIT(1.0f);
	modelHCPiramideIIT = glm::translate(modelHCPiramideIIT, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCPiramideIIT = glm::rotate(modelHCPiramideIIT, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
	modelHCPiramideIIT = glm::rotate(modelHCPiramideIIT, 180.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));


	//Piramide inferior derecha trasera
	glm::mat4 modelHCPiramideIDT(1.0f);
	modelHCPiramideIDT = glm::translate(modelHCPiramideIDT, glm::vec3(0.0f, 0.0f, -7.0f));
	modelHCPiramideIDT = glm::rotate(modelHCPiramideIDT, 180.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));


	//PLANO DEL PISO

	glm::mat4 modelPiso(1.0f);
	modelPiso = glm::translate(modelPiso, glm::vec3(0.0f, -1.35f, -7.0f));
	/*

	//COHETE ESPACIAL

	//CUERPO
	glm::mat4 modelCuerpoCohete(1.0f);
	modelCuerpoCohete = glm::translate(modelCuerpoCohete, glm::vec3(-4.0f, 0.0f, -12.0f));
	modelCuerpoCohete = glm::scale(modelCuerpoCohete, glm::vec3(1.0f, 3.0f, 1.0f));

	//PUNTA
	glm::mat4 modelPuntaCohete(1.0f);
	modelPuntaCohete = glm::translate(modelPuntaCohete, glm::vec3(-4.0f, 2.25f, -12.0f));
	modelPuntaCohete = glm::scale(modelPuntaCohete, glm::vec3(1.0f, 1.5f, 1.0f));
	
	//VENTANA
	glm::mat4 modelVentanaCohete(1.0f);
	modelVentanaCohete = glm::translate(modelVentanaCohete, glm::vec3(-4.0f, 0.8f, -11.0f));
	modelVentanaCohete = glm::scale(modelVentanaCohete, glm::vec3(0.45f, 0.45f, 0.45f));

	//BASE
	glm::mat4 modelBaseCohete(1.0f);
	modelBaseCohete = glm::translate(modelBaseCohete, glm::vec3(-4.0f, -1.75f, -12.1f));
	modelBaseCohete = glm::scale(modelBaseCohete, glm::vec3(1.5f, 0.5f, 1.5f));

	//ALETAS
	//ALETA IZQUIERDA
	glm::mat4 modelAletaIzqCohete(1.0f);
	modelAletaIzqCohete = glm::translate(modelAletaIzqCohete, glm::vec3(-5.5f, -1.0f, -12.0f));
	modelAletaIzqCohete = glm::rotate(modelAletaIzqCohete, 90.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));

	//ALETA DERECHA
	glm::mat4 modelAletaDerCohete(1.0f);
	modelAletaDerCohete = glm::translate(modelAletaDerCohete, glm::vec3(-2.5f, -1.0f, -12.0f));
	modelAletaDerCohete = glm::rotate(modelAletaDerCohete, -90.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));

	//ALETA FRONTAL
	glm::mat4 modelAletaFrontalCohete(1.0f);
	modelAletaFrontalCohete = glm::translate(modelAletaFrontalCohete, glm::vec3(-4.0f, -1.0f, -10.5f));
	modelAletaFrontalCohete = glm::rotate(modelAletaFrontalCohete, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

	//ALETA TRASERA
	glm::mat4 modelAletaTraseraCohete(1.0f);
	modelAletaTraseraCohete = glm::translate(modelAletaTraseraCohete, glm::vec3(-4.0f, -1.0f, -13.5f));
	modelAletaTraseraCohete = glm::rotate(modelAletaTraseraCohete, -90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));

	cohete
	*/



	//ACTIVIDAD 2

	//PIRAMIDE DE NYAN CAT
	glm::mat4 modelPiramideActividad2(1.0f);
	modelPiramideActividad2 = glm::translate(modelPiramideActividad2, glm::vec3(2.5f, 0.0f, -8.0f));
	
	//JUEGO DE ENDER

//PIRAMIDE 1
//ZONA BAJA SUPERIOR
	glm::mat4 modelPiramideColor1(1.0f);
	modelPiramideColor1 = glm::translate(modelPiramideColor1, glm::vec3(0.0f, -0.25f, -8.0f));
	modelPiramideColor1 = glm::scale(modelPiramideColor1, glm::vec3(1.0f, 0.50f, 1.0f));
	modelPiramideColor1 = glm::rotate(modelPiramideColor1, 90.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));

	//PIRAMIDE 2
	//ZONA BAJA INFERIOR
	glm::mat4 modelPiramideColor2(1.0f);
	modelPiramideColor2 = glm::translate(modelPiramideColor2, glm::vec3(0.0f, -0.75f, -8.0f));
	modelPiramideColor2 = glm::rotate(modelPiramideColor2, 180.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
	modelPiramideColor2 = glm::scale(modelPiramideColor2, glm::vec3(1.0f, 0.50f, 1.0f));

	//PIRAMIDE 3
	//ZONA DERECHA INFERIOR
	glm::mat4 modelPiramideColor3(1.0f);
	modelPiramideColor3 = glm::translate(modelPiramideColor3, glm::vec3(0.75f, 0.0f, -8.0f));
	modelPiramideColor3 = glm::rotate(modelPiramideColor3, -90.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
	modelPiramideColor3 = glm::scale(modelPiramideColor3, glm::vec3(1.0f, 0.50f, 1.0f));

	//PIRAMIDE 4
	//ZONA DERECHA SUPERIOR
	glm::mat4 modelPiramideColor4(1.0f);
	modelPiramideColor4 = glm::translate(modelPiramideColor4, glm::vec3(0.25f, 0.0f, -8.0f));
	modelPiramideColor4 = glm::rotate(modelPiramideColor4, 90.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
	modelPiramideColor4 = glm::scale(modelPiramideColor4, glm::vec3(1.0f, 0.50f, 1.0f));

	//PIRAMIDE 5
	//ZONA TRASERA INFERIOR
	glm::mat4 modelPiramideColor5(1.0f);
	modelPiramideColor5 = glm::translate(modelPiramideColor5, glm::vec3(0.0f, 0.0f, -8.25f));
	modelPiramideColor5 = glm::rotate(modelPiramideColor5, 90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
	modelPiramideColor5 = glm::scale(modelPiramideColor5, glm::vec3(1.0f, 0.50f, 1.0f));

	//PIRAMIDE 6
	//ZONA TRASERA SUPERIOR
	glm::mat4 modelPiramideColor6(1.0f);
	modelPiramideColor6 = glm::translate(modelPiramideColor6, glm::vec3(0.0f, 0.0f, -8.75f));
	modelPiramideColor6 = glm::rotate(modelPiramideColor6, -90.0f * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
	modelPiramideColor6 = glm::scale(modelPiramideColor6, glm::vec3(1.0f, 0.50f, 1.0f));

	//PIRAMIDE 7
	//ZONA SUPERIOR INFERIOR
	glm::mat4 modelPiramideColor7(1.0f);
	modelPiramideColor7 = glm::translate(modelPiramideColor7, glm::vec3(0.0f, 0.25f, -8.0f));
	modelPiramideColor7 = glm::rotate(modelPiramideColor7, 180.0f * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
	modelPiramideColor7 = glm::scale(modelPiramideColor7, glm::vec3(1.0f, 0.50f, 1.0f));
	modelPiramideColor7 = glm::rotate(modelPiramideColor7, 90.0f * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));

	//PIRAMIDE 8
	//ZONA SUPERIOR SUPERIOR
	glm::mat4 modelPiramideColor8(1.0f);
	modelPiramideColor8 = glm::translate(modelPiramideColor8, glm::vec3(0.0f, 0.75f, -8.0f));
	modelPiramideColor8 = glm::scale(modelPiramideColor8, glm::vec3(1.0f, 0.50f, 1.0f));


	while (!mainWindow.getShouldClose())
	{

		GLfloat now = glfwGetTime();
		deltaTime = now - lastTime;
		deltaTime += (now - lastTime) / limitFPS;
		lastTime = now;
		//Recibir eventos del usuario
		glfwPollEvents();
		//C�mara
		camera.keyControl(mainWindow.getsKeys(), deltaTime);
		camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());

		//Limpiar la ventana
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //Se agrega limpiar el buffer de profundidad
		
		
		/*
		shaderList[0].useShader();
		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		model = glm::mat4(1.0);
		//Traslaci�n inicial para posicionar en -Z a los objetos
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, -4.0f));
		//otras transformaciones para el objeto
		//model = glm::scale(model, glm::vec3(0.5f,0.5f,0.5f));
		model = glm::rotate(model, glm::radians(mainWindow.getrotax()), glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::rotate(model, glm::radians(mainWindow.getrotay()), glm::vec3(0.0f, 1.0f, 0.0f));  //al presionar la tecla Y se rota sobre el eje y
		model = glm::rotate(model, glm::radians(mainWindow.getrotaz()), glm::vec3(0.0f, 0.0f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		//la l�nea de proyecci�n solo se manda una vez a menos que en tiempo de ejecuci�n
		//se programe cambio entre proyecci�n ortogonal y perspectiva
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));
		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color)); //para cambiar el color del objetos
		meshList[1]->RenderMeshGeometry(); //dibuja cubo, pir�mide triangular y pir�mide base cuadrangular
		//meshList[3]->RenderMeshGeometry(); //dibuja las figuras geom�tricas cilindro, cono
		//sp.render(); //dibuja esfera
		*/
		/*
		//ejercicio: Instanciar primitivas geom�tricas para recrear las figuras 2 y 3 de la pr�ctica pasada en 3D,
		//se requiere que exista piso
		*/
		/*

		/*RECORDATORIO
		* Cubo						meshList[0]
		* Piramide Triangular		meshList[1]
		* cilindro					meshList[2]
		* Cono						meshList[3]
		* Piramide Cuadrangular		meshList[4]
		*/

		/*
		//TRIANGULO AMARILLO
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelCuboAmarillo));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();

		//Cubo rojo
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelCuboRojo));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();
		//Cubo morado
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelCuboMagenta));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();

		//Cubo verde
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelCuboVerde));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();

		//Cubo azul

		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelCuboAzul));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();

		//rombo cafe
		//PIRAMIDE CAFE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideCafe));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.478f, 0.255f, 0.067f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));


		meshList[4]->RenderMeshGeometry();


		//La trifuerza que no es trifuerza pero tiene la forma de la trifuerza
				/*RECORDATORIO
		* Cubo						meshList[0]
		* Piramide Triangular		meshList[1]
		* cilindro					meshList[2]
		* Cono						meshList[3]
		* Piramide Cuadrangular		meshList[4]
		

		//triangulo amarillo
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelTrianguloAmarillo));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();

		//triangulo verde
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelTrianguloVerde));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();

		//triangulo rojo
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelTrianguloRojo));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();

		//triangulo azul
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelTrianguloMagenta));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();
		*/
		//HOLOCRON JEDI
		/*RECORDATORIO
		* Cubo						meshList[0]
		* Piramide Triangular		meshList[1]
		* cilindro					meshList[2]
		* Cono						meshList[3]
		* Piramide Cuadrangular		meshList[4]
		*/
		//LAS ESQUINAS DEBEN SER PIRAMIDES Y EL CUBO ES CENTRAL EN CADA CARA
		
		//===============================================================
		//PLANO DEL PISO
		//===============================================================

		/*
		//PISO NEGRO
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiso));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[6]->RenderMeshGeometry();

		//===============================================================
		//3 CUBOS CENTRALES
		//===============================================================


		//CUBO FRONTAL Y TRASERO
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboFrontalTrasero));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();


		//CUBO IZQUIERDO Y DERECHO
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboIzquierdoDerecho));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.478f, 0.255f, 0.067f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();


		//CUBO SUPERIOR E INFERIOR
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCCuboSuperiorInferior));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();
		//===============================================================
		//PIRAMIDES DE LAS ESQUINAS
		//===============================================================


		//PIRAMIDE SUPERIOR IZQUIERDA FRONTAL - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSIF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();


		//PIRAMIDE SUPERIOR DERECHA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSDF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();


		//PIRAMIDE INFERIOR IZQUIERDA FRONTAL - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIIF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();


		//PIRAMIDE INFERIOR DERECHA FRONTAL - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIDF));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();


		//PIRAMIDE SUPERIOR IZQUIERDA TRASERA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSIT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();


		//PIRAMIDE SUPERIOR DERECHA TRASERA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideSDT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();


		//PIRAMIDE INFERIOR IZQUIERDA TRASERA - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIIT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();


		//PIRAMIDE INFERIOR DERECHA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelHCPiramideIDT));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[5]->RenderMeshGeometry();
		*/
		
		
		//===============================================================
		//REPORTE DE PR�CTICA
		/* 1.- Crear un cohete espacial con instancias de pir�mides, cilindros, esferas, conos y cubos
		* 
		* 2.-Generar la figura de union de 8 pir�mides como la que se adjunta. Cada cara de cada pir�mide debe tener un color diferente. 
		* considerando que al ver una sola pir�mide desde todos los �ngulos se ver�an las caras triangulares de color: roja, verde, amarilla y magenta.
		* Y l a cara cuadrada se debe de ver color azul 
		* 
		* 
		*/
/*
		//CUERPO DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelCuerpoCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.8f, 0.8f, 0.8f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[2]->RenderMeshGeometry();

		//PUNTA DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPuntaCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[3]->RenderMeshGeometry();
		
		//BASE DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelBaseCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.4f, 0.4f, 0.4f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[0]->RenderMeshGeometry();

		//ALETAS DEL COHETE

		//ALETA IZQUIERDA DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelAletaIzqCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();
		
		//ALETA DERECHA DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelAletaDerCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();

		//ALETA FRONTAL DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelAletaFrontalCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();

		//ALETA TRASERA DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelAletaTraseraCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[4]->RenderMeshGeometry();

		//VENTANA DEL COHETE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelVentanaCohete));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.5f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		sp.render();

		/*RECORDATORIO
* Cubo						meshList[0]
* Piramide Triangular		meshList[1]
* cilindro					meshList[2]
* Cono						meshList[3]
* Piramide Cuadrangular		meshList[4]
* CrearPiramideHolocron();//�ndice 5 en MeshList
* CrearPiso();//�ndice 6 en MeshList
*/
		//===============================================================
		//ACTIVIDAD 2
		//PIRAMIDE CUADRANGULAR DE COLORES
		//===============================================================


		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		//===============================================================
		//JUEGO DE ENDER
		
		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		

		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideActividad2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		//===============================================================
		//JUEGO DE ENDER
		
		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor1));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		//===============================================================
		//PIRAMIDE INFERIOR
		//JUEGO DE ENDER

		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor2));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		//===============================================================
		//PIRAMIDE DE LA DERECHA INFERIOR
				//JUEGO DE ENDER

		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

				//PIRAMIDE DE LA DERECHA
				//JUEGO DE ENDER

		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor3));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();
		
		//===============================================================
		//PIRAMIDE DE LA DERECHA SUPERIOR
		//JUEGO DE ENDER

//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor4));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor4));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor4));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor4));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor4));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		//PIRAMIDE TRASERA SUPERIOR
		//JUEGO DE ENDER

		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor5));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor5));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor5));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor5));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor5));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();


		//PIRAMIDE TRASERA SUPERIOR
		//JUEGO DE ENDER

		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor6));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor6));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor6));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor6));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor6));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		//PIRAMIDE SUPERIOR INFERIOR
		//JUEGO DE ENDER

		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor7));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor7));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor7));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor7));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor7));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();

		//PIRAMIDE TRASERA
		//JUEGO DE ENDER
		
		//CARA FRONTAL - ROJA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor8));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[7]->RenderMeshGeometry();


		//CARA IZQUIERDA - VERDE
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor8));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[8]->RenderMeshGeometry();


		//CARA TRASERA - AMARILLA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor8));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 1.0f, 0.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[9]->RenderMeshGeometry();


		//CARA DERECHA - MAGENTA
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor8));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(1.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[10]->RenderMeshGeometry();


		//BASE CUADRADA - AZUL
		shaderList[0].useShader();

		uniformModel = shaderList[0].getModelLocation();
		uniformProjection = shaderList[0].getProjectLocation();
		uniformView = shaderList[0].getViewLocation();
		uniformColor = shaderList[0].getColorLocation();

		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(modelPiramideColor8));
		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));

		color = glm::vec3(0.0f, 0.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));

		meshList[11]->RenderMeshGeometry();
		
		glUseProgram(0);
		mainWindow.swapBuffers();
	}
	return 0;
}