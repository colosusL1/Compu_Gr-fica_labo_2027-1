#pragma once
#include <vector>
#include <cmath>
#include <glm.hpp>
#include <gtc\matrix_transform.hpp>
#include "circuito.h"

//Recorrido cerrado de una nave sobre el circuito (linea central del camino RR64)
class RutaNave
{
public:
	//Convierte los puntos del modelo a mundo con la MISMA matriz con la que se dibuja la pista.
	//alturaSobreCamino: separacion entre la nave y el camino, en unidades de mundo.
	void construir(const glm::mat4& modeloPista, float alturaSobreCamino)
	{
		puntos.clear();
		for (int i = 0; i < circuitoNumPuntos; i++)
		{
			glm::vec4 p = modeloPista * glm::vec4(circuitoPuntos[i][0], circuitoPuntos[i][1], circuitoPuntos[i][2], 1.0f);
			puntos.push_back(glm::vec3(p) + glm::vec3(0.0f, alturaSobreCamino, 0.0f));
		}
		int n = (int)puntos.size();
		longitud = 0.0f;
		for (int i = 0; i < n; i++)
			longitud += glm::length(puntos[(i + 1) % n] - puntos[i]);
		espaciado = longitud / n;
	}

	float getLongitud() const { return longitud; }

	//Posicion sobre el circuito a la distancia s (unidades de mundo). Es un lazo: s se repite.
	glm::vec3 posicion(float s) const
	{
		int n = (int)puntos.size();
		float f = s / espaciado;
		f = f - n * floorf(f / n);			//modulo positivo
		int i = (int)f;
		float u = f - i;
		glm::vec3 p0 = puntos[(i - 1 + n) % n];
		glm::vec3 p1 = puntos[i % n];
		glm::vec3 p2 = puntos[(i + 1) % n];
		glm::vec3 p3 = puntos[(i + 2) % n];
		float u2 = u * u, u3 = u2 * u;
		//spline Catmull-Rom: pasa por todos los puntos y suaviza las curvas
		return 0.5f * ((2.0f * p1) + (p2 - p0) * u
			+ (2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3) * u2
			+ (3.0f * p1 - p0 - 3.0f * p2 + p3) * u3);
	}

	//Matriz de modelo de la nave en la distancia s.
	//factorInclinacion: cuanto se inclina en las curvas (si se inclina hacia afuera, ponerlo negativo).
	//pendiente (salida): componente vertical del rumbo; > 0 sube, < 0 baja.
	glm::mat4 matrizNave(float s, float factorInclinacion, float& pendiente) const
	{
		float d = espaciado * 0.75f;
		glm::vec3 pos = posicion(s);
		glm::vec3 t0 = glm::normalize(pos - posicion(s - d));
		glm::vec3 t1 = glm::normalize(posicion(s + d) - pos);
		glm::vec3 rumbo = glm::normalize(t0 + t1);
		pendiente = rumbo.y;

		//giro horizontal entre el tramo anterior y el siguiente
		float giro = t0.z * t1.x - t0.x * t1.z;
		float roll = glm::clamp(-factorInclinacion * giro, -0.6f, 0.6f);

		//vector "arriba" inclinado hacia el interior de la curva
		glm::vec3 arriba = glm::vec3(glm::rotate(glm::mat4(1.0f), roll, rumbo) * glm::vec4(0.0f, 1.0f, 0.0f, 0.0f));

		glm::mat4 m = glm::inverse(glm::lookAt(pos, pos + rumbo, arriba));
		m = glm::rotate(m, 3.14159265f, glm::vec3(0.0f, 1.0f, 0.0f));	//el Catzpaw apunta hacia +Z
		return m;
	}

private:
	std::vector<glm::vec3> puntos;
	float espaciado = 1.0f;
	float longitud = 0.0f;
};
